<?php

/* This program is used to understand the types of comments in PHP.
*/

?>

<?= "PHP is Nice!" //Comments are fine here ?>

<?php

#Hash Comment
echo "Welcome to PHP!"; #This is welcome message

?>