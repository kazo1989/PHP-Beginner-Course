<?= "PHP is Interesting !"; // Test Comment ?>

<?php

// Testz Comment 2
echo "Welcome to PHP!"; // Test Comment 3
?>