<?php
/*
This program is used to understand the types of comments in PHP.
Isn't is nice?
*/
?>

<?= "PHP is nice!" /*  Multiline can aslo be singleline */ ?>

<?php

/*
echo "Welcome to PHP!"; //This is echo method
*/

?>