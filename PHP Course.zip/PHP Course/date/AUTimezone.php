<?php

echo date_default_timezone_get() . "<br>";
echo date("m/d/y h:i:s a") . "<br>";
date_default_timezone_set("Europe/Podgorica");
echo date("m/d/y h:i:s a") . "<br>";
echo date_default_timezone_get() . "<br>";

?>