<?php

$dateArr = getdate();
var_dump($dateArr);

echo "<br>";
echo "<br>";

foreach($dateArr as $format => $val){
    echo "$format => $val" . "<br>";
}

?>