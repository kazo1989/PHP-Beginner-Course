<?php

// namespace is a kezword to define a Namespace
namespace myconstants_new;

// Constants are allowed in namespace
const FILE_NAME = __NAMESPACE__ . "\NamespaceConstants.php" . "<br>";

?>