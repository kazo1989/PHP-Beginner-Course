<?php

namespace constantfile;

const FILE_NAME = "MyNamespaces.php"

?>