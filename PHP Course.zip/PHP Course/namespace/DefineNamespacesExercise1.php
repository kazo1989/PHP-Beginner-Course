<?php

include "MyNamespace.php";
include "MySubNamespaces.php";

echo constantfile\FILE_NAME;
echo "<hr>";
echo notconstantfile\SubNamespace\LES_BROWN;
echo "<hr>";
echo notconstantfile\SubNamespace\FILE_NAME;

?>