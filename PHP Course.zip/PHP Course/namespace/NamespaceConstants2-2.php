<?php

namespace SubNamespaces\Sub2;

const FILE_NAME = "Sub2\NamespaceConstants2-2.php" . "<br>";

// ---------------

namespace SubNamespaces\Sub3;

const FILE_NAME = "Sub3\NamespaceConstants2-2.php" . "<br>";

?>