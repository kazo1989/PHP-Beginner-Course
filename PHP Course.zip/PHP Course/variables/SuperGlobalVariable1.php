<?php

// Sample 1
global $message;
$message = "Welcome to PHP !";

echo $GLOBALS['message'] . "<br>";

?>