<?php

$name;
echo $name;

// Ternary operator
echo isset($name) ? "Variable is set" . "<br>" : "Variable is not set" . "<br>";

$name = "Petar";
echo isset($name) ? "Variable is set" . "<br>" : "Variable is not set" . "<br>";

$firstname = "Janko";
$name = $firstname;

echo isset($name) ? "Variable is set" . "<br>" : "Variable is not set" . "<br>";

?>