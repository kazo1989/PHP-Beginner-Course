<?php

// Sample 1
$name = "Petar";

function print_name() {
    $name = "Jakov";
    echo $name;
}

print_name();
echo "<br>" . $name;
?>