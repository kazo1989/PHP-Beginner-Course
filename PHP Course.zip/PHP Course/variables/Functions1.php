<?php

// Sample 1
// Define a function

// Function Declaration
function add() {
    // Function body
    $firstvalue = 10;
    $secondvalue = 20;
    $total = $firstvalue + $secondvalue;
    echo $total;
}

add();