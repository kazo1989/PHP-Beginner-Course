<?php

	//Sample 1
	$length = 10;
	$width = 20;
	$area = $length * $width;
	echo "Area: $area";

?>