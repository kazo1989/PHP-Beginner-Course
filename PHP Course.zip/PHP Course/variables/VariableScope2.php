<?php

// Sample 1
$name = "Petar";

function print_name() {
    $name = "Jakov";
    echo $name;
}

print_name();
echo $name;

// SAmple 2
$message = "Welcome to PHP!";
function print_message() {
    echo $message;
}

print_message();
?>