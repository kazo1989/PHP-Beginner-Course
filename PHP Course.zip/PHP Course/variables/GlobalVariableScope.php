<?php
 
// Sample 1
global $name;
$name = "Petar";

function print_name() {
    $name = "Jakov";
    echo $name;
}

print_name();
echo "<br>" . $name;

// Sample 2
global $message;
$message = "Wellcome to PHP !";

function print_message() {
    echo $message;
}

print_message();
echo $message . "<br>";

// Sample 3
global $message1;
$message1 = "Wellcome to PHP :)";

function print_message1() {
    global $message1;
    $message1 = "This is changed value !"; 
    echo $message1;
}

print_message1();
echo "<br>" . $message1;

?>