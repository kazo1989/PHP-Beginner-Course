<?php

echo __LINE__ . "<br>";
echo __FILE__ . "<br>";
echo __DIR__ . "<br>";

function test1212() {
    echo 'Test' . '<br>';
    echo __FUNCTION__ . '<br>';
}
  
test1212();

?>