<?php

function customExceptionHnadler($exception){
    echo "Caught Exception: " . $exception->getMessage() . "<br>";
}

set_exception_handler("customExceptionHnadler");

function divide($x, $y) : int{

    try {

        if($y <= 0){
            throw new Exception("Division by 0 might have happened.");
        }
    
        $result = $x / $y;

    } catch (Exception $e) {
        throw new Exception("Divide method input param is less than 0." . $e->getMessage() );
    }

    return $result;
}

divide(1, 0);

?>