<?php

function divide($x, $y) : int{

    if($y <= 0){
        throw new Exception("Division by 0 might have happened.");
    }

    $result = $x / $y;
    return $result;
}

try{
    $result = divide(1, 0);
}catch(Exception $ex){
    echo "Caught Exception: " . $ex->getMessage() . "<br>";
}

?>