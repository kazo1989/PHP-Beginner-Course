<!doctype html>
<html>

<head>
    <title>
        PHP Language Basics
    </title>
</head>

<body>

    <h1>Example for PHP Basics</h1>

    <p>
        <?php
        echo "PHP is interesting to work with!<br>\n";
        ?>
    </p>
    <hr>
    <?=
    "
    PHP is Interpreted Server Side

    Scripting Language. It is really

    fun to work with.

    <br>
    ";
    ?>

    <?= "Did you read the \"PHP CookBook\" book?"; ?>

</body>

</html>