<!-- Sample 1-->

<?php
echo "This          is       a        Test";


?>

<!-- Sample 2 -->
<?="

<hr>

<p>

You are free to type.

anything inside this

block.

</p>




"?>