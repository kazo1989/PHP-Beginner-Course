<?php

// Open a File
// Read file Content
// Close the file

// File Modes:
// r - read mode
// w - write mod
// a - append mode

// Read the File - Method 1
$fileName = "content.txt";

// Good Practise - Check does the file exist
if(!file_exists($fileName)){
    if(!is_file($fileName)){
        die("File does not exists.");
    }
}

// Read the File
$content = file_get_contents($fileName);

// Print the Content of the file
echo $content . "<hr>";


// Read the File - Method 2 - RECOMMENDED
// Open a File
$fileHandler = fopen($fileName, "r");
$fileSize = filesize($fileName);

// Read the File content
$content = fread($fileHandler, $fileSize);
echo $content . "<hr>";

// Close a File
fclose($fileHandler);



// Write Operations - Method 1 - RECOMMENDED
$fileHandler = fopen($fileName, "w") or die("Unable to Write the File.");

fwrite($fileHandler, "Ja jesam Petar.");

fclose($fileHandler);


// Write Operations - Method 2
$fileName = "NewFile.txt";
file_put_contents($fileName, "Idalje sam Petar.");

?>