<?php

/*

1) List all Files in a Directory
2) Check for Specific Files in a Directory
3) Check If the Name is a Directory or File.
4) Create Directory
5) Copy Files between Directories.

*/

// Sample 1: List all Files in a Directory
//scandir
$path = "TestFolder1";
$result = scandir($path);
var_dump($result);

?>