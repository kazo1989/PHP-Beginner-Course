<?php

/*

function function_name(param_1, ... , param_n)
{
    statement_1;
    statement_2;
    ...
    statement_n;

    return return_value;
}

*/

// Define a Function
function printEvenNumbers($limit){
    for ($index = 0; $index <= $limit; $index++) { 
        if($index%2 === 0){
            echo "Even Number : $index" . "<br>";
        }
    }
}

// Call a Function
printEvenNumbers(20);
echo "<hr>";
printEvenNumbers("20"); // Bad Spika, nije prakticno
echo "<hr>";

function add($a, $b){
    return $a + $b;
}

echo add(10, 20);

?>