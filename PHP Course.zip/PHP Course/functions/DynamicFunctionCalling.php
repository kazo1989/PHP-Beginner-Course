<?php

function add($a, $b): int{
    return $a + $b;
}

$addFunction = "add";

echo $addFunction . "<br>";

echo $addFunction(1, 2) . "<br>";

?>