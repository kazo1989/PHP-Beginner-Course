<?php

declare(strict_types=1);

function printOddNumber(int $limit, $skipNumber = 3){
    for($index = 0; $index <= $limit; $index++){
        if($index == $skipNumber){
            continue;
        }
        if($index%2 != 0){
            echo "Odd Number : " . $index . "<br>";
        }
    }
}

// Optional parameters should be the last
function printEvenNumber($skipNumber = -1, int $limit){
    for($index = 0; $index <= $limit; $index++){
        if($index == $skipNumber){
            continue;
        }
        if($index%2 == 0){
            echo "Even Number : " . $index . "<br>";
        }
    }
}

printOddNumber(10);
echo "<br>";
printEvenNumber(4, 10);
echo "<br>";

?>