<?php

class Database{

    // Desine a variable
    public $dbConnection;
    public $records;

    function openConnection() : bool{}
    
    function fetchRecord($id) : bool{}

}

?>