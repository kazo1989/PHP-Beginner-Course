<?php

/*

1.) Class name first letter should always starts with capital letters.
2.) File name should match with class name. Easy nto follow.
3.) One file should have one class. You can have multiple.
4.) 'class' is the keyword used to define class
5.) class is opened and closed with {} like functions.

*/

class Car{

    function helloClass(){
        echo "Hello from Car Class" . "<br>";
    }

}

?>