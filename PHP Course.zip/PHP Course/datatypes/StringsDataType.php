<?php

/*

Strings are defined in Double quotes and Single Quotes.
Double Quotes string will interpolate variables values and single quote does not.
No limited to how much string variable holds but limited with system memory.
Use Escape Character to escape double quotes inside double quotes and other characters.
String methods are available to work with string manipulation
 
*/

// Define String and use Strings
$name1 = "John, Smith";
$name2 = 'John, Smith';
echo "$name1 and $name2" . "<br>";
echo '$name1 and $name2' . "<br>";

// Combine Strings
$name3 = $name1 . " - " . $name2;
echo $name3 . "<br>";

// Use a Backslack to escape Characters
$name4 = "This is a \"Special\" String";
echo $name4 . "<br>";

$name4 = '\t\tThis is a \"Special\" String';
echo $name4 . "<br>";

echo strlen( $name4 ) . "<br>";

// How to Search the Manual https://www.php.net/ for String Methods.

?>