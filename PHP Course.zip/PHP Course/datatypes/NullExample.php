<?php

/*

NULL is case insensitive. null / NULL are same
null is used to initialize a variable with empty value.
unset() and is_null() methods
Most common use case is to check if the variable has a value or empty

*/

// Define and Check NULL
$name = null;
echo $name . "<br>";
echo ( $name ) ? "Has Value" : "Empty";
echo "<br>";

// Check if the variable is NULL or not
$name = "0";
echo ( $name ) ? "Has Value" : "Empty";
echo "<br>";
echo ( !is_null($name) ) ? "Has Value" : "Empty";
echo "<br>";

// Remove the number from the program and memory
unset($name);
echo ( !is_null(@$name) ) ? "Has Value" : "Empty";
echo "<br>";

?>