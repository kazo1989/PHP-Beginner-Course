<?php

// 1) Check for Odd or Even Numbers and Print it.
// Using 'else if'

$input_number = 10;
$result = $input_number % 2;

if ( $result ) {
    echo "$input_number is Odd Number";
} else if ( !$result ) {
    echo "$input_number is Even Number";
}

echo "<hr>";

/*
    if ( condition1 ) {
        // Code to be executed if condition1 is true
    } else   if ( condition2 ) {
        // Code to be executed if the condition1 is false and condition2 is true
    } else {
        // Code to be executed if both condition1 and condition2 are false
    }

*/

// Check if the input_numebr is greater tha 10

if ( $input_number > 10 ) {
    echo "Number is greater than 10.";
} elseif ( $input_number == 10 ) {
    echo "Number is equal to 10.";
} else {
    echo "Number is less than 10.";
}

?>