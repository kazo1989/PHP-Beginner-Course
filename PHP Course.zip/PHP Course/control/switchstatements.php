<?php

// 1) Check for Odd or Even Numbers and Print it.
// Using 'else if'

$input_number = 10;
$result = $input_number % 2;

if ( $result ) {
    echo "$input_number is Odd Number";
} else if ( !$result ) {
    echo "$input_number is Even Number";
}

echo "<hr>";

switch ( $result ){
    case 1:
        echo "Odd Number";
        break;
    case 0:
        echo "Even Number";
        break;
    default:
        echo "Invalid Input";
}

echo "<hr>";

if ( $input_number > 10 ) {
    echo "Number is greater than 10.";
} elseif ( $input_number == 10 ) {
    echo "Number is equal to 10.";
} else {
    echo "Number is less than 10.";
}

echo "<hr>";

switch ( true ) {
    case $input_number > 10:
        echo "Number is greater than 10.";
        break;
    case $input_number == 10:
        echo "Number is equal to 10.";
        break;
    case $input_number < 10:
        echo "Number is equal to 10.";
        break;
    default:
        echo "Invalid Input";
}

echo "<hr>";

$weekday = "Friday";

switch ( $weekday ) {
    case "Monday":
        echo "Monday";
        break;
    case "Friday":
        echo "Friday";
        break;
    default:
        echo "Other";
}

?>