<?php

/*

1) Syntax of if and else condition
2) Check if the inputs given by user is correct.
3) if condition statement without braces.
4) Check if Student is passed or failed.

*/

// Sample 1
// 1) Syntax of if and else condition
// Please follow the coding style

$some_boolean_condition = false;

if( $some_boolean_condition ) {

    echo "This is a IF block condition" . "<br>";
    echo "This is a True condition" . "<br>";

} else {

    echo "This is a ELSE block condition" . "<br>";
    echo "This is a False condition" . "<br>";

}

echo "<hr>";

$one_more_boolean_condition = false;

if( $some_boolean_condition && $one_more_boolean_condition ) {

    echo "This is a IF block condition" . "<br>";
    echo "This is a True condition" . "<br>";

} else {

    echo "This is a ELSE block condition" . "<br>";
    echo "This is a False condition" . "<br>";

}

echo "<hr>"

?>

<!-- php and html are mixed together with ifelse -->

<!doctype html>
<html>
<head>
    <title>
        if else Statements
    </title>
</head>
<body>

    <?php if ( $some_boolean_condition || true ) { ?>
        
        <h1>This is a true condition.</h1>

    <?php } else { ?>

        <h1>This is False Condition.</h1>

    <?php } ?>

</body>
</html>