<?php

/*

for(initialization; condition; increment){
    // Code to be executed
}

*/

// Print Odd Numbers from 1 to 10.

// Sample 1 -- Recommended Way

for ( $value = 1; $value <= 10; $value++ ) {

    $result = $value % 2;
    if ( $result > 0) {
        echo "Odd Number---" . $value . "<br>";
    }
}

echo "<hr>";

// Sample 2

$value = 1;
for ( ; $value <= 10; $value++ ) {

    $result = $value % 2;
    if ( $result < 1) {
        echo "Odd Number---" . $value . "<br>";
    }
}

echo "<hr>";

// Sample 3

$value = 0;
for ( ; $value <= 10; ++$value ) {

    $result = $value % 2;
    if ( $result > 0) {
        echo "Odd Number---" . $value . "<br>";
    }
}

echo "<hr>";

// Sample 4

$value = 1;
for ( ; $value <= 10; ) {

    $result = $value % 2;
    if ( $result > 0) {
        echo "Odd Number---" . $value . "<br>";
    }

    $value++;

}

echo "<hr>";

// Sample 5

/*
$value = 1;
for ( ; true; ) {

    $result = $value % 2;
    if ( $result > 0) {
        echo "Odd Number---" . $value . "<br>";
    }

    $value++;

}
*/

?>