<?php

echo "My name is Petar Kažić.";
print "My favourite thing to do is to play football.";

?>

<?= "My hobbies are programming, coding, design and tech in general"; ?>