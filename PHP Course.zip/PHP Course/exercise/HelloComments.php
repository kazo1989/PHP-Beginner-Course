<?php

/*
U ovom radu pričam o sebi, kako se zovem i šta volim da radim
*/

// Reći ću moje ime, zatim šta volim da radim.

?>

<?= "Moje ime je Petar Kažić.";  // Moje ime?>

<?php

// O meni
echo "Moja omiljena stvar je fudbal.";

print "Takodje, mnogo volim programiranje, kodiranje i dizajn, dakle tehnologiju uopšte.";

?>