<?php

/*

AND - every one should be true
OR - any one can be true
&& - every one should be true
|| - any one can be true
! - if not

*/

// Sample 1
// Greet Hello, Name if the user is logged in and has permission
$permission = true;
$loggedin = true;
$user = "John Smith";
echo ($permission and $loggedin) ? "Hello $user!" : "Hello Guest";
echo PHP_EOL;

// Sample 2
// Check if student passed any one exam
$student = "John";
$mathsPassed = true;
$sciencePassed = true;
echo ($mathsPassed or $sciencePassed) ? "$student has passed." : "$student has not passed.";
echo PHP_EOL;

// Sample 3
// Find the difference between and &&
$result1 = true && false;
$result2 = true and false;

echo ($result1) ? "true" : "false";
echo PHP_EOL;
echo ($result2) ? "true" : "false";
echo PHP_EOL;

// Sample 4
// Find the difference between or ||
$result1 = true || false;
$result2 = true or false;

echo ($result1) ? "true" : "false";
echo PHP_EOL;
echo ($result2) ? "true" : "false";
echo PHP_EOL;

// Sample 5
// Check if student is not passed and print the results
$total = 34;
$passingMarks = 35;
$isPassed = ($total >= $passingMarks) ? true : false;

echo (!$isPassed) ? "Not Passed" : "Passed";

?>