<?php

/*

++ = Incremental by 1
-- = Decremental by 1

*/

// Use ++ Increment
$counter = 10;
$counter += 1;
echo $counter . PHP_EOL;

// Post Increment Operator
echo $counter++ . PHP_EOL;
echo $counter . PHP_EOL;

// Pre Increment Operator
echo ++$counter . PHP_EOL;
echo $counter . PHP_EOL;

// Use -- Increment
$counter = 10;
$counter -= 1;
echo $counter . PHP_EOL;

// Post Increment Operator
echo $counter-- . PHP_EOL;
echo $counter . PHP_EOL;

// Pre Increment Operator
echo --$counter . PHP_EOL;
echo $counter . PHP_EOL;

?>