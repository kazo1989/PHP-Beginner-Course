<?php

// `` - backticks, koriste se za execution komandi u konzoli

// Windows
echo `ver`;

?>