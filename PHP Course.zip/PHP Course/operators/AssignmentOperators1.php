<?php

/*

= - Assignment Operator used to assign values
+= - Add Assignment Operator - .=
-= - Subtract Assignment Operator
*= - Multiple Assignment Operator
/= - Divide Assignment Operator
%= - Modulus Assignment Operator

*/

// Sample 1
// Assign value 10 to variable $marks
$marks = 10;

// Assign any name String to Variable $name
$name = "John Smith";

// Use += Operator
$counter = 1;
$counter = $counter + 1;
$counter += $counter;
echo $counter . PHP_EOL;

$marks += 10;
echo $marks . PHP_EOL;

echo $name . PHP_EOL;
$names = "Petar";
$names .= " i ";
$names .= "Jakov";
echo $names . PHP_EOL;

?>