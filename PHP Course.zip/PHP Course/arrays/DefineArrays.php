<?php

// Define an Array
// Reference: https://www.php.net/manual/en/language.types.array.php
// As of PHP 5.4 you can also use the short array syntax, which replaces array() with [].

$arr = [ 1, 122, "Petar", true, 3.4];

// Function to print an array
var_dump($arr);

echo "<br>";

// Human Readable
print_r($arr);

echo $arr . "<br>"; // Error, do not use echo to print arrays

// Access and print arrays
echo $arr[0] . "<br>";
echo $arr[1] . "<br>";
echo $arr[2] . "<br>";
echo $arr[3] . "<br>";
echo $arr[4] . "<br>";

echo "<hr>";

echo "$arr[0]" . "<br>";
echo "$arr[1]" . "<br>";
echo "$arr[2]" . "<br>";
echo "$arr[3]" . "<br>";
echo "$arr[4]" . "<br>";

// $arr is a Array Variable
// $arr[0] is a Array Element
// 0 is a index of Array
// Array index starts with 0 not 1
// Arrays can store any type of value - String, Integer or Boolean
// Arrays has a length based on the number of elements it has.
// You can have array inside an array - more about it in next lecture.
// Usecase: Collection of variables together.

echo "Array lenght: " . count($arr) . "<br>";

// Loop thru the Array using foor loop
for ($count = 0; $count < count($arr); $count++) {
    echo $arr[$count] . "<br>";
}

// Access Array element inside the String using a constant
const ARRAY_ELEMENT = 1;

echo $arr[ARRAY_ELEMENT] . "<br>";
echo "$arr[ARRAY_ELEMENT]" . "<br>";
echo "{$arr[ARRAY_ELEMENT]}" . "<br>";

// Change Array Elements
$arr[0] = 1;
$arr[1] = 2;
$arr[2] = 3;
$arr[3] = 4;
$arr[4] = 5;
print_r($arr);

echo "<br>";

// Change Array Elements
$arr[0] = 1;
$arr[1] = "Petar";
$arr[2] = true;
$arr[3] = false;
$arr[4] = 5.5;
print_r($arr);

echo "<br>";

// Store any type of data types
// See the indentation works.
$arr1 = [
    1,
    "String",
    false,
    21.2
];

print_r($arr1);

?>