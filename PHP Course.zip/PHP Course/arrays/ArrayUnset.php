<?php

$arr = [1, 2, 3, 4, 5];
print_r($arr);
echo "<hr>";

unset($arr[4]);
print_r($arr);
echo "<hr>";

$arr[] = 5;
print_r($arr);
echo "<hr>";

$arr1 = [ "first" => 1, 2, 3, 4, "last" => 5];
print_r($arr1);
echo "<hr>";

unset($arr1["last"]);
print_r($arr1);
echo "<hr>";

$arr1["last"] = 5;
print_r($arr1);
echo "<hr>";

$arr1[] = 6;
print_r($arr1);
echo "<hr>";

?>