<?php

//In Associative Arrays, you specify the index.
// index => value
// => is a special symbol to represent key and value.
// key => value - key is the index and value is the value at that index.

// Indexed Array
$arr = [ "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat", "Sun"];
var_dump($arr);
echo "<br>";
foreach($arr as $values){
    echo $values . "<br>";
}

echo "<hr>";
    
    // Associative Array
$arr = [ "Monday" => "Mon", 1 => "Tues", 2 => "Wed", 3 => "Thurs", 4 => "Fri", 5 => "Sat", 6 => "Sun"];
var_dump($arr);
echo "<br>";
foreach($arr as $values){
    echo $values . "<br>";
}

echo "<hr>";

foreach($arr as $key1 => $values1){
    echo $key1 . " => " . $values1 . "<br>";
}

echo "<hr>";

// Print all the Keys
print_r(array_keys($arr));

echo "<hr>";

// Access only the keys
foreach(array_keys($arr) as $key1){
    echo $key1 . "<br>";
}

echo "<hr>";

// Access only the value
foreach($arr as $value){
    echo $value . "<br>";
}

echo "<hr>";

// Example...

$userDetails = [
    "John" => "john@gmail.com",
    "Jenny" => "jenny@gmail.com",
    "Ajit" => "ajit@gmail.com"
];

var_dump($userDetails);

echo "<br>";

echo $userDetails["John"] . "<br>";
echo $userDetails["Jenny"] . "<br>";
echo $userDetails["Ajit"] . "<br>";

$userDetails["Mary"] = "mary@gmail.com";

var_dump($userDetails);

echo "<hr>";

// Error - 0 is not the key anymore. Index is not element position.
// Echo $userDetails[0] . PHP_EOL;

$userDetails[0] = "user@gmail.com";
var_dump($userDetails);

echo "<br>";

echo $userDetails[0] . "<br>";

echo "<hr>";

$userDetails[] = [ "Jane" => "jane@gmail.com" ];
var_dump($userDetails);

echo "<hr>";

// Add an element at end of the aray

$userDetails = [
    "John" => "john@gmail.com",
    "Jenny" => "jenny@gmail.com",
    "Ajit" => "ajit@gmail.com"
];

$userDetails["Jane"] = "jane@gmail.com";

var_dump($userDetails);

echo "<br>";

echo $userDetails["Jane"];

?>