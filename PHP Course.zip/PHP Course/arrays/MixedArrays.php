<?php

//If Index is not specified, PHP will use the increment of the largest previously used integer key.

$arr = [];
$arr[0] = 1;
$arr[2] = "Tekst";
$arr[4] = true;
$arr[10] = 14.5;

// Adding new values to array
$arr[] = "New String--11";
$arr[] = "New String--12";

var_dump($arr);
echo "<br>";
echo "<br>";
print_r($arr);
echo "<br>";
echo "<br>";

// Test

$arr[100] = "New String--100";
$arr[] = "New String--101";

var_dump($arr);
echo "<br>";
echo "<br>";
print_r($arr);
echo "<br>";
echo "<br>";

$arr[0] = "Previously 1 and now Changed Value";
foreach($arr as $values) {
    echo $values . "<br>";
}

echo "<br>";

// Curious to know what is inside index of 1
// For loop is bad sometimes. Recommendation is to use foreach loop for arrays
echo @$arr[1] . "<br>";

?>