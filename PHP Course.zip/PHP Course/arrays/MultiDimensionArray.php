<?php

// Array inside an array is called as Multi Dimension array
// Array holding one or multiple arrays

//Single Dimension - Indexed Array
$arr = [ 0, 1, 2, 3, 4, 5 ];
var_dump($arr);
echo "<hr>";

//Single Dimension / Associative Array
$arr1 = [
    "John" => "john@gmail.com",
    "Jenny" => "jenny@gmail.com",
    "Ajit" => "ajit@gmail.com"

];
var_dump($arr1);
echo "<hr>";

// Multi Dimension with Index
$arr2 = [
    [0, 1, 2, 3, 4, 5],
    [6, 7, 8],
    [9, 10]
];

var_dump($arr2);
echo "<hr>";

foreach ($arr2 as $singleArr) {
    var_dump($singleArr);
    echo "<br>";
}

echo "<hr>";

foreach ($arr2 as $singleArr) {
    foreach ($singleArr as $values) {
        var_dump($values);
        echo "<br>";
    }
}

echo "<hr>";

foreach ($arr2 as $singleArr) {
    echo "[";
    foreach ($singleArr as $values) {
        echo $values . ",";
    }
    echo "]" . "<br>";
}

echo "<hr>";

//Multi Dimention with Associative
$arr3 = [
    "emaillist1" => [
        "John1" => "john1@gmail.com",
        "Jenny1" => "jenny1@gmail.com",
        "Ajit1" => "ajit1@gmail.com"
    ],
    "emaillist2" => [
        "John2" => "john2@gmail.com",
        "Jenny2" => "jenny2@gmail.com",
        "Ajit2" => "ajit2@gmail.com"
    ]

];

foreach($arr3 as $valueArray){
    foreach($valueArray as $values){
        echo $values . "<br>";
    }
}

echo "<hr>";

//Access all the Key Value Pair. Key is String and Values are Arrays
foreach($arr3 as $key => $valueArray){
    echo "<hr>";
    echo "Values for Key: $key" . "<br>";
    foreach( $valueArray as $values){
        echo $values . "<br>";
    }
}

?>