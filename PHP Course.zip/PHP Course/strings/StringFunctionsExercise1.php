<!doctype html>
<html>
<head>
    <title>
        Strings
    </title>
</head>
<body>

<h1>Exercise 1: String Functions</h1>

<h2>Find the Given Word in the String (Case Insensitive)</h2>

<?php

$content = "Ja sam Petar imam 17 godina i mnogo volim fudbal.";
$findWord = "FUDBAL";
$position = stripos($content, $findWord);

if ($position == true) {
    echo $findWord . " has been found." . "<br>";
} else {
    echo "We couldn't find that word." . "<br>";
}

?>

<h2>Calculate the Length of the String</h2>

<?php

echo "String lenght: " . strlen($content) . "<br>";

?>

<h2>Remove White Spaces from left in the String</h2>

<?php

echo ltrim($content) . "<br>";

?>

<h2>Reverse the String</h2>

<?php

echo strrev($content) . "<br>";

?>


</body>
</html>