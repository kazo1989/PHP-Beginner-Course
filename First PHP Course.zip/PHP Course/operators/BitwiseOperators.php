<?php

/*
& - AND
| - OR
^ - XOR
~ - NOT - Works on one operator like ++ and -- - Unary Operator -- Reverse the BITS
*/

// HOW BITS WORK
// 0 - bits - 0000
// 1 - bits - 0001
// 2 - bits - 0010
// 3 - bits - 0011
// 4 - bits - 0100
// 5 - bits - 0101

// 1 i 1 = 1 / TRUE I TRUE = TRUE
// 0 i 0 = 0 / FALSE I FALSE = FALSE
// 0 i 1 = 0
// 1 i 0 = 0

error_reporting(E_ERROR | E_PARSE);

$first = 0; // 0000
$second = 1; // 0001

// (0000) & (0001) = (0&0) & (0&0) & (0&0) & (0&1) = 0000
echo $first & $second . PHP_EOL . "\n";


$first = 2; // 0010
$second = 3; // 0011

// (0010) & (0011) = (0&0) & (0&0) & (1&1) & (0&1) = 0010
echo $first & $second . PHP_EOL . "\n"; 

echo $first | $second . PHP_EOL . "\n";

echo $first ^ $second . PHP_EOL . "\n";

echo ~$first . PHP_EOL . "\n";
echo ~$second . PHP_EOL . "\n";

echo $php_errormsg . PHP_EOL . "\n";

?>