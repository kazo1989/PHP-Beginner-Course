<?php

/*

(condition) ? true : false;

*/

// Sample 1
// Ternary Operator
$flag = (true) ? "Correct" : "Wrong";
echo $flag . PHP_EOL;

$flag = (false) ? "Correct" : "Wrong";
echo $flag . PHP_EOL;

$flag = (10>5) ? "Correct" : "Wrong";
echo $flag . PHP_EOL;

$flag = (20<10) ? "Correct" : "Wrong";
echo $flag . PHP_EOL;

?>