<?php

// @ = Suppress Error and 'skip' it.

@$value = 1/0;

echo $php_errormsg . PHP_EOL;
echo 'Hello !' . PHP_EOL;

?>