<?php

namespace SubNamespaces\Sub1;

const FILE_NAME = "Sub1\NamespaceConstants2-1.php" . "<br>"

?>