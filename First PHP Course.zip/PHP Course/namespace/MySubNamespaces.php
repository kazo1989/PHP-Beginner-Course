<?php

namespace notconstantfile\SubNamespace;

const LES_BROWN = "It's not over, until I WIN !!!";
const FILE_NAME = __NAMESPACE__ . "\MySubNamespace.php";

?>