<?php

// Include Namespace file
include "NamespaceConstants.php";

// Access the Namespace
echo myconstants_new\FILE_NAME;

?>