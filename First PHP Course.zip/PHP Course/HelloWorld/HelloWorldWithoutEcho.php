<?= "Hello World!"; ?>
<?= 'Hello World!'; ?>