<?php
echo 'Welcome to PHP!';
print "It's my new language!"
?>

<?= 'PHP is iteresting!' ?>
<?= 'PHP is nice!'; ?>

<?=
'PHP is great!'; 
'PHP is awesome!'
?>