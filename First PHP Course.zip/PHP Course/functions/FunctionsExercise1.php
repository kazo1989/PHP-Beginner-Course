<?php

function getFullName(string $firstName, string $lastName) : string{
    $fullName = $firstName . " " . $lastName;
    return $fullName;
}

echo getFullName(Petar, Kazic);

?>