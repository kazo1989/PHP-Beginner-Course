<?php

declare(strict_types=1);

function printOddNumber(int $limit, $skipNumber){
    for($index = 0; $index <= $limit; $index++){
        if($index == $skipNumber){
            continue;
        }
        if($index%2 != 0){
            echo "Odd Number : " . $index . "<br>";
        }
    }
}

// Call the function
printOddNumber(20, "3");

echo "<hr>";

printOddNumber("20", "3");

echo "<hr>";

printOddNumber(20);

?>