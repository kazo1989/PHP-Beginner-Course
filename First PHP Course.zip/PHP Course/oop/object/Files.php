<?php

class Files{

    function displayContent($filename) : bool {

        $result = true;

        try{

            echo "Read the content of the file $filename" . "<br>";

            $content = file_get_contents($filename);

            echo "Displaying content of the file: $filename" . "<br>";

            echo $content;
        } catch(Exception $e){
            $result = false;
        }

        return $result;

    }

}

$files1 = new Files();
$files1->displayContent("Test.txt");

echo "<br>";
echo "<br>";

$files2 = new Files();
$files2->displayContent("Goal.txt");

?>