<?php

class Car{

    public $brand;
    public $model;
    public $year;
    public $color;

    function sayHello(){
        echo "Hello from Car Class." . "<br>";
    }

}

$car1 = new Car();
$car1->brand = "Renault";
$car1->model = "Clio";
$car1->year = "2016";
$car1->color = "white";
$car1->sayHello();

echo "My brand new $car1->brand $car1->model, from $car1->year, is $car1->color color." . "<br>";

echo "<br>";

$car2 = new Car();
$car2->brand = "Rolls Royce";
$car2->model = "Phantom";
$car2->year = "2027";
$car2->color = "silver";
$car2->sayHello();

echo "My brand new $car2->brand $car2->model, from $car2->year, is $car2->color color." . "<br>";

?>