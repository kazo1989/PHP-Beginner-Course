<?php

class Users{

    function fetchUsers($id) : bool {
        
    }

    function deleteUsers($id) : bool {

    }

}

$user1 = new Users();
$user1->fetchUser(101);
$user1->fetchUser(102);

$user1->deleteUser(102);

?>