<?php

// Calculate the employee salary

class Employee{

    public $id;
    public $name;
    public $workingHoursPerDay = 8;
    public $hourlyRate = 15;
    public $totalLeaveTaken;
    public $workingDays;

    function getSalaryAmount($totalDays) : int {

        // $this is a special variable which can be used to access class properties.

        $this->workingDays = $totalDays - $this->totalLeaveTaken;

        $salary = $this->workingDays * $this->workingHoursPerDay * $this->hourlyRate;

        return $salary;
    }

}

$emp1 = new Employee();
$emp1->id = 1;
$emp1->name = "Petar";
$emp1->totalLeaveTaken = 4;
$salary = $emp1->getSalaryAmount(24);
echo "$emp1->name has worked for $emp1->workingDays and taken a total of $emp1->totalLeaveTaken leaves." . "<br>";
echo "$emp1->name salary is $salary." . "<br>";

echo "<br>";

$emp2 = new Employee();
$emp2->id = 2;
$emp2->name = "Jakov";
$emp2->totalLeaveTaken = 7;
$salary = $emp2->getSalaryAmount(24);
echo "$emp2->name has worked for $emp2->workingDays and taken a total of $emp2->totalLeaveTaken leaves." . "<br>";
echo "$emp2->name salary is $salary." . "<br>";

?>