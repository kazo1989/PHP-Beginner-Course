<?php

/*

\n - New Line - <br>
\r - Carriage Return - <br>
\t - Tab - &nbsp;
\$ - Dollar Sign
\" - Double Quotes
\' - Single Quotes
\\ - Single Backslach

*/

echo 'This isn\'t the way we want to print !<br>';

echo "This is printed on new line !<br>";

echo "<br>We have tabs &nbsp;&nbsp; here<br>";

echo "This is a \"Special\" character inside the PHP !";

?> im