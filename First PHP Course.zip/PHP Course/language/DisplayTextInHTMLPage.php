<!doctype html>
<html>

<head>
    <title>
        PHP Developer Profile
    </title>
</head>

<body>
    <h1>About Me:</h1>

    <h2>
        <?php
        echo 'I\'m Srini and I love to work with PHP!';
        ?>
    </h2>

    <hr>

    <h1>Skills:</h1>
    <p>
        <?php
        echo "Able to develop website with HTML, CSS, JS and PHP Server Side Programming Language.";
        ?>
    </p>


</body>

</html>