<?php

/*

function customExceptionHnadler($exception){
    echo "Caught Exception: " . $exception->getMessage() . "<br>";
}

set_exception_handler("customExceptionHnadler");
throw new Exception("Exception is raised!")

*/

function customExceptionHnadler($exception){
    echo "Caught Exception: " . $exception->getMessage() . "<br>";
}

set_exception_handler("customExceptionHnadler");

function divide($x, $y) : int{

    if($y <= 0){
        throw new Exception("Division by 0 might have happened.");
    }

    $result = $x / $y;
    return $result;
}

divide(1, 0);

?>