<?php

function customExceptionHnadler($exception){
    echo "Caught Exception: " . $exception->getMessage() . "<br>";
}

set_exception_handler("customExceptionHnadler");

try{
    throw new Exception("Exception is raised!");
}finally{
    echo "This line is executed before exception.";
}


?>