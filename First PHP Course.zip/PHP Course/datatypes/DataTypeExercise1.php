<!doctype html>
<html>
<head>
    <title>
        Data Types
    </title>
</head>
<body>

<h1>Exercise 1: Use All Data Types</h1>

<?php

$integers = 10;
$double = 17.3;
$boolean = true;
$strings = "Petar";

echo ($boolean) ? "Moje ime je $strings, imam tacno $double godina. Moj omiljeni broj je $integers." : "Moje ime je Lazar. imam tacno 13.8 godina. Moj omiljeni broj je 7.";

?>

<h2>Calculate the area using Length and breath using Integer:</h2>

<?php

$length = 8;
$breath = 10;
$area = $length * $breath;

echo "Povrsina mojeg buduceg kupatila je $area !!!";

?>

<h2>Calculate Student Exact Marks Percentage with Double:</h2>

<?php

$maths = 50;
$science = 45;
$total = $maths + $science;
$totalMarks = 100;
$percentage = $total / $totalMarks;

echo "Postotak je : $percentage. <br> P.S. Ovo nije postotak, samo neki bezveze primjer."

?>

<h2>Check if the user has admin roles:</h2>

<?php

$user = "Petar Kazic";
$hasAdminRoles = true;

echo ( ($user === "Petar Kazic") && $hasAdminRoles ) ? "Petar je admin, ali je i vlasnik, osnivac i kralj." : "VRATITE MI ADMINA !!!";

?>

<h2>Define and Display a User Name using Strings:</h2>

<?php

$name = "Petar";
$lastName = "Kazic";

echo "Moje puno ime je $name $lastName";

?>

<h2>Check if the variable is null or not:</h2>

<?php

$varijabla = null;

echo ( is_null($varijabla) ) ? "Variabla je NULL" : "Variabla nije NULL";

?>

</body>
</html>