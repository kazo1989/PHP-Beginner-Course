<?php

$inputvalue = 0;

if ($inputvalue < 10) {
    goto error_block;
}

exit();
error_block:
    echo "This is a error block and will execute anyway." . "<br>";

for($count = 1; $count <= 10; $count++) { 
    if ($count == 2) {
        goto loop2;
    }
}

exit();
loop2:
    echo "Counter value is $count."

?>