<?php

namespace configfile;
const MAX_NUMBERS = 10;

?>