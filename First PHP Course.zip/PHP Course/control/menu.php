<ul>
    <li><a href="header.php" target="blank">Header</a></li>
    <li><a href="menu.php" target="blank">Menu</a></li>
    <li><a href="footer.html" target="blank">Footer</a></li>
</ul>