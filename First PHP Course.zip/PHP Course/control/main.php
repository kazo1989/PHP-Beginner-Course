<!DOCTYPE html>
<html>
<?php

    include "header.php";

?>

<body>

    <?php
    
        require "menu.php";
        require_once "menu.php";
    
    ?>

    <h1>Exercise on how to include files</h1>

    <?php
    
        include "footer.html";

    ?>

</body>
</html>