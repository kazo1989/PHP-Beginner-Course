<?php


function checkUserRoles ($userRoles) {

    if ( empty($userRoles) ){
        echo "Pick Some Role!!!" . "<br>";
        return;
    }

    switch ($userRoles) {
        case "Admin":
            echo "Hello Admin!" . "<br>";
            break;
        case "Editor":
            echo "Hello Editor!" . "<br>";
            break;
        default:
            echo "Roles are empty!" . "<br>";
    }

}

checkUserRoles ("Admin");
checkUserRoles ("");
checkUserRoles ("Editor");

?>