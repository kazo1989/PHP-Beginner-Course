<?php

/*

1) Syntax of if and else condition
2) Check if the inputs given by user is correct.
3) if condition statement without braces.
4) Check if Student is passed or failed.

*/

// Sample 1
// 1) Syntax of if and else condition
// Please follow the coding style

$some_boolean_condition = false;

if ($some_boolean_condition) {

    echo "This is a IF block condition" . "<br>";
    echo "This is a True condition" . "<br>";
} else {

    echo "This is a ELSE block condition" . "<br>";
    echo "This is a False condition" . "<br>";
}

echo "<br>";

$one_more_boolean_condition = false;

if ($some_boolean_condition && $one_more_boolean_condition) {

    echo "This is a IF block condition" . "<br>";
    echo "This is a True condition" . "<br>";
} else {

    echo "This is a ELSE block condition" . "<br>";
    echo "This is a False condition" . "<br>";
}

echo "<hr>"

?>

<!-- php and html are mixed together with ifelse -->

<!doctype html>
<html>

<head>
    <title>
        if else Statements
    </title>
</head>

<body>

    <?php if ($some_boolean_condition || true) { ?>

        <h1>This is a true condition.</h1>

    <?php } else { ?>

        <h1>This is False Condition.</h1>

    <?php } ?>

</body>

</html>

<?php

echo "<hr>";

// Sample 2
// 2) Check if the inputs given by user is correct.

$input1 = "Some text from the User";

$input2 = 34;

// Condition 1
if (!is_null($input1)) {
    echo '$input1 is not empty';
} else {
    echo '$input1 is empty';
}

echo "<br>";

// Condition 2
if (isset($input1) && !is_null($input1)) {
    echo '$input1 is not empty';
} else {
    echo '$input1 is empty';
}

echo "<br>";

// Condition 2
if ($input1 != "") {
    echo '$input1 is not empty';
} else {
    echo '$input1 is empty';
}

echo "<br>";

// Best Way to check if field is empty
if (!empty($input1)) {
    echo '$input1 is not empty';
    echo '$input1 is empty';
} else {
}

echo "<br>";

if ($input2 >= 34) {
    echo '$input2 is greater or equal to 34';
} else {
    echo '$input2 is less than 34';
}

?>

<?php

// Sample 3
// 3) if condition statement without braces.

echo "<hr>";

$some_boolean_condition = false;

if ($some_boolean_condition)
    echo "This is a True condition" . "<br>";
else
    echo "This is a False condition" . "<br>";

/*

if ($some_boolean_condition)

    echo "This is a True condition" . "<br>";
    echo "This is a False condition" . "<br>";

else

    echo "This is a False condition" . "<br>";
    echo "This is a True condition" . "<br>";

*/

// One Liner
if ($some_boolean_condition) echo "This is a True condition" . "<br>";
else echo "This is a False condition" . "<br>";

echo "<hr>";
echo "<hr>";

// Recomended Practise
if ($some_boolean_condition) {
    echo "THIS IS TRUE CONDITION" . "<br>";
} else {
    echo "THIS IS FALSE CONDITION" . "<br>";
}

?>