<?php

// Check if file exist
$fileName = "MyFolder.txt";

if(file_exists($fileName)){
    
    if(is_dir($fileName)){
        die("It is a Directory, not a File.");
    }
    
    echo "File Exists." . "<br>";

    // Copy Files
    copy($fileName, "CopyFile.txt");
    copy("CopyFile.txt", "CopyFile1.txt");
    
    // Rename the Files
    rename("CopyFile1.txt", "Renamed.txt");
    copy("Renamed.txt", "RenamedFileDeleted.txt");

    // Delete the File
    unlink("RenamedFileDeleted.txt");
    
}else{

    echo "File / Directory does not exists." . "<br>";

    die("No Such a File/Directory.");
}

?>