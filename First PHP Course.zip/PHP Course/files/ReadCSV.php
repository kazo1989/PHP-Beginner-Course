<?php

// Read Entire Content
$fileName = "students.csv";
$content = file_get_contents($fileName);
print_r($content);
echo "<br>";
var_dump($content);

echo "<hr>";

// Read Line by Line
$csvFile = file($fileName);
var_dump($csvFile);
echo "<br>";
foreach($csvFile as $line){
    echo $line . "<br>";
}

echo "<hr>";

$csvFile = file($fileName);
var_dump($csvFile);
echo "<br>";
foreach($csvFile as $line){
    $data[] = str_getcsv($line);
    print_r($data);
    echo "<br>";
}

echo "<hr>";

$csv = array_map("str_getcsv", file($fileName));
print_r($csv);

?>