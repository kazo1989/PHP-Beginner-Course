<?php

/*

1) List all Files in a Directory
2) Check for Specific Files in a Directory
3) Check If the Name is a Directory or File.
4) Create Directory
5) Copy Files between Directories.

*/

// Sample 1: List all Files in a Directory

// scandir

$path = "TestFolder1";
$result = scandir($path);
var_dump($result);

echo "<br>";

// Remove . and ..
foreach($result as $dir){
    if($dir != "." && $dir != ".."){
        echo $dir . "<br>";
    }
}

// Remove . and ..
$directory = array_diff($result, [".", ".."]);
var_dump($directory);

echo "<br>";

foreach($directory as $dir){
    echo $dir . "<br>";
}

// Sample 2 and 3
// 2) Check for Specific Files in a Directory
// 3) Check If the Name is a Directory or File.

// is_file or is_dir

$result = scandir($path);
$result = array_diff($result, [".", ".."]);;

echo "<hr>";

foreach($result as $dir){
    if(is_file($path . "/" . $dir)){
        echo $dir . "<br>";
    }
}

echo "<hr>";

// Sample 4: Create Directory
$result = glob("*.php");
var_dump($result);

if( !file_exists("TestFolder3")){
    mkdir("TestFolder3");
}

echo "<hr>";

// Sample 5: Copy Files between Directories.

// copy(source, target)

copy("TestFolder1/Dummy.txt", "TestFolder3/Test.txt")

?>