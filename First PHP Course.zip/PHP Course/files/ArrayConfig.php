<?php

$settings = parse_ini_file("test.ini");
var_dump($settings);
echo "<hr>";
print_r($settings);
echo "<hr>";

foreach($settings as $key => $value){
    echo $key . " => " . $value . "<br>";
}

echo "<hr>";

echo $settings["white"] . "<br>";
echo $settings["font2"] . "<br>";

?>