<?php

/*

1) No need to use $ to use constants.
2) Constants are defined only via define method.
3) Value can be asigned only once.
4) Constant has global scope. Can access anywhere.
5) Constants can be used to access constants.

*/

$name = "John Smith";
define (name, "John Smith");

echo $name . name;

// Changing Constants and Variables
$name = "Walter White";
define (name, "Walter White");

echo $name . name;

echo "<hr>";

function print_constant(){
    echo $name . name;
}

print_constant();

?>