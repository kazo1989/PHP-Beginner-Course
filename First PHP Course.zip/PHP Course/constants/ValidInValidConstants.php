<?php

// Good Practice 1: Always use UPPERCASE to define constants.
define(LANGUAGE, "PHP");
define(VERSION, 7.3);

// Good Practice 2: Do not use constants like __CONSTANTS__
define(__CONSTANTS__, "Wrong Practise")

?>

<?php

// Good Practice 1: Always use UPPERCASE to define constants.
define(LANGUAGE, "PHP");
define(VERSION, 7.3);

// Good Practice 2: Do not use constants like __CONSTANTS__
define(__CONSTANTS__, "Wrong Practise");

//Good Practise 3: Avoid the same name as Variable to avoid confusion
$message = "This is PHP Constants!";
define(message, "This is another message");

// Constant naming rules are similar to Variables.
// Do not start a variable or constant with integer.
$_1message = "Hello";
define(_1message, "Hello");
echo $_1message . _1message;

?>