<?php

echo date_create("now")->format("Y-m-d H:i:s") . "<br>";
echo date_create("+1 day")->format("Y-m-d H:i:s") . "<br>";
echo date_create("-5 hours, -5 days")->format("Y-m-d H:i:s") . "<br>";

echo "<br>";

$strTime = strtotime ("2019-05-21 9:00:00");
echo date("d-m-y h:i:s", $strTime) . "<br>";

?>