<?PHP

Echo "Hello World ";
ECHO "Hello World <br>";

// Variable as Case Sensitive
$name = "PHP";
$Name = "Petar";
echo "I am $Name and I study $name.";
?>