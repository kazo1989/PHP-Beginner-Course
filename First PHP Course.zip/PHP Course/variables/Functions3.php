<?php

// Sample 1
// Define a function

// Function Declaration
function add() {
    // Function body
    $firstvalue = 10;
    $secondvalue = 20;
    $total = $firstvalue + $secondvalue;
    echo $total;
}

// Calling the function
add();

// Sample 2
/*
function add() {
    echo "Duplicate function";
}
*/

// Sample 3
welcome();
function welcome() {
    echo "Welcome to PHP !";
}