<!doctype html>
<html>

<head>
    <title>
        Variables and Constants
    </title>
</head>

<body>

    <!-- SAmple 1 -->
    <?php

    $aboutme = "I am Petar and I love football !";
    echo "<h1>About Me:</h1>";
    echo $aboutme; // Print the Variable

    ?>

    <!-- SAmple 1 -->
    <?php

    $aboutme = "Text is changed NOW !";
    echo $aboutme;
    ?>
</body>

</html>