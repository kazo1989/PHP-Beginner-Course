<?php

$male = "John Smith";
$gender = "male";

echo $gender . "<br>";
echo $$gender . "<br>";

$student = "John Jordan";
$male = "student";
$gender = "male";

echo "{${${$gender}}}";

?>