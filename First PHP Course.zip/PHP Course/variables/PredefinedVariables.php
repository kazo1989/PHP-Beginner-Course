<?php

@$val = 1/0;

echo $php_errormsg;

?>