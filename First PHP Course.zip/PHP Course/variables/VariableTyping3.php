<?php

	//Sample 1
	$length = 10;
	$width = 20;
	$area = $length * $width;
	echo "Area: $area <br>";

	//Sample 2
	$length = "20";
	$width = 20;
	$area = $length * $width; // PHP sam convertuje string u broj ako je broj, ako nije javlja se greška
	echo "Area: $area <br>";


	//Sample 3
	$length = "1";
	$width = "a";
	$area = $length * $width;
	echo "Area: $area <br>";