<?php

$solarPlanets = [
    "planets" => [
        "Sun" => [ "temp" => "hot", "color" => "red" ],
        "Moon" => [ "temp" => "cold", "color"  => "white" ],
        "Earth" => [ "temp" => "normal", "color" => "blue" ]
    ]
];

foreach($solarPlanets as $key => $planets){
    foreach($planets as $planetName => $planetInfo){
        echo "<strong>" . $planetName . "</strong>" . " is " . $planetInfo["temp"] . " and " . $planetInfo["color"] . "." . "<br>";
    }
}

?>