<?php

$employee = [
    1,
    2,
    3,
    4,
    5,
    6
];

echo "Ukupno zaposlenih: " . count($employee) . "<br>";

foreach($employee as $values){
    echo "ID Zaposlenog: $values" . "<br>";
}

echo "<hr>";

$employee1 = [
    1 => [
        "Ime" => "Petar Kažić",
        "Posao" => "Founder"
    ],
    2 => [
        "Ime" => "Luka Marinović",
        "Posao" => "Co-Founder"
    ],
    3 => [
        "Ime" => "Jakov Kažić",
        "Posao" => "Co-Founder"
    ],
    4 => [
        "Ime" => "Lazar Kažić",
        "Posao" => "Co-Founder"
    ],
    5 => [
        "Ime" => "Pavle Drobac",
        "Posao" => "Manager"
    ],
    6 => [
        "Ime" => "Luka Ćirović",
        "Posao" => "Manager"
    ],

];

foreach($employee1 as $id => $values){
    echo $values["Ime"] . " - " . "<strong>" . $values["Posao"] . "</strong>" . "<br>";
}

?>