<?php

//Remember [] means empty arrays

//Empty Arrays
$arr = [];

echo count($arr) . "<br>";
var_dump($arr);
echo "<br>";
print_r($arr);
echo "<br>";

if (empty($arr)){
    echo "Array is empty." . "<br>";
}

$arr = 10; // Converted Number to Integer
var_dump($arr);
echo "<br>";

$arr = [10];
var_dump($arr);
echo "<br>";

$arr[0] = [10];
//Index 0 holds an array which has 10 as first value
var_dump($arr);
echo "<br>";

//Reset the Array
$arr = [];
var_dump($arr);
echo "<br>";

$arr = [[]]; // Very important to understand this concept of arrays.
var_dump($arr);
echo "<br>";

?>