<?php

/*

foreach($array as $value){
    # code to be executed
}

*/

$arr = [ "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
var_dump($arr);

echo "<br>";

$counter = 0;

foreach ( $arr as $values ) {
    echo "[$counter] => $values" . "<br>";
    // echo "[$counter] => $values => $arr[$counter]" . "<br>";
    $counter++;
}

echo "<hr>";

$counter = 0;
$arr = [ "Mon", 1, "Wed", true, "Fri", 7.5, "Sun"];

foreach ($arr as $values ) {
    echo "[$counter] => $values" . "<br>";
    // echo "[$counter] => $values => $arr[$counter]" . "<br>";
    $counter++;
}

?>