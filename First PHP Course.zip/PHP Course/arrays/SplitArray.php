<?php

//String to Array
$students = "John, Parker, Amit, Jacob, Jim";
$studentsArr = explode(",", $students);
print_r($studentsArr);
echo "<hr>";

//Array to String
$studentList = implode("|", $studentsArr);
echo $studentList;
echo "<hr>";

//Limited Number of Array Elements
$studentsArr = explode(",", $students, 3);
print_r($studentsArr);
echo "<hr>";

?>