<?php

// sort() and rsort()
// Indexed Array
$arr = [ 5, 2, 4, 3, 0, 1];
print_r( $arr );
echo "<hr>";
sort($arr);
print_r( $arr );
echo "<hr>";
rsort($arr);
print_r( $arr );
echo "<hr>";
echo "<hr>";

// asort() and arsort()
// Associative Array
$arr1 = [ "3" => "John", "1" => "Ajit", "2" => "Roger"];
print_r($arr1);
echo "<hr>";
asort($arr1);
print_r($arr1);
echo "<hr>";
arsort($arr1);
print_r($arr1);
echo "<hr>";
echo "<hr>";

// ksort() and krsort()
// Associative Array
print_r( $arr1 );
echo "<hr>";
ksort($arr1);
print_r( $arr1 );
echo "<hr>";
krsort($arr1);
print_r( $arr1 );
echo "<hr>";

?>