<?= "PHP is Nice!" #This is hash comment ?>

<?php

#This a message printed
echo "Welcome to PHP!"; #This is echo method

?>