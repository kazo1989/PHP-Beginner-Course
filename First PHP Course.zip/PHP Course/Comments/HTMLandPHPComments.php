<!-- This is HTML Comment -->

<?= "Hello!" // This is PHP Comment ?>

<!-- 
    <?php
        echo "Will I be printed 1?"
    ?> 
-->

<?php
echo "<!--Will I be printed 2?-->"
?>

<?php
/*
?>

Will I be pritned 3?

<?php
*/
?>

<!--
<?php
/*
?>

Will I be pritned 4?

<?php
*/
?>
-->