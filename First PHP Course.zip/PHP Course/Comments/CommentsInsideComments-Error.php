<?php

/*

    This is multiline comment.
    // This is singleline comment
    # Hash Comment

    /*

    This is another multiline inside multiline.

    */

*/


?>