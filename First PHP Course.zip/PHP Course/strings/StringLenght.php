<?php

    $name = "John, Smith";
    echo strlen($name) . "<br>";

    echo strlen($name1) . "<br>";

    $name2 = "";
    echo strlen($name2) . "<br>";

    $name2 = null;
    echo strlen($name2) . "<br>";