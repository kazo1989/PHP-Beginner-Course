<?php

// Find a string position inside the string
$content = "This is a very long content and it is a string.";
$findContentWord = "content";
$position = strpos( $content, $findContentWord);

echo $position . "<br>";

// Case insensitive 'stripos'

$findContentWord = "CONTENT";
$position = stripos( $content, $findContentWord);

echo $position . "<br>";

$findContentWord = "content1";
$position = stripos( $content, $findContentWord);

echo $position . "<br>";

echo true . "<br>";
echo false . "<br>";
echo true . "<br>";

if ( $position === false ) {
    echo "Not Found" . "<br>";
}

$findContentWord = "This";
$position = strpos( $content, $findContentWord);

echo $position . "<br>";

//Able to find but still canot check.
//Because position is 0 and 0 in condition is treated as false.
if( !$position ) {
    echo "$position Value" . "<br>";
    echo "2) Not Found!" . "<br>";
}

if( !0 ){
    echo "False Condition" . "<br>";
}

if( $position === false ) {
    echo "3) Not Found!" . "<br>";
}

?>