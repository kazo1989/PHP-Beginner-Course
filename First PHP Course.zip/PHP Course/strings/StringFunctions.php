<?php

/*
     
1) Learn to use the following String Functions
        - Number of Words
        - Replace Strings
        - Reverse Strings
        - Remove White Spaces
        - Shuffle Strings
        - Find Position case insenstive.
        - Upper and Lowercase
        - Word Wrap the String and display it.

*/

$content = "You can do string operations easily with String functions.";
$findWord = "operations";
$postion = false;

echo $content . "<br>";

// Number of Words
echo "Number of words in string: " . str_word_count($content) . "<br>";

// Replace Strings
echo "Find and Replace 'operations' with 'manipulation': " . str_replace("operations", "manipulation", $content) . "<br>";

//Reverse Strings
echo strrev($content) . "<br>";

//Remove White Spaces - ltrim and rtrim


//Shuffle Strings
echo str_shuffle($content) . "<br>";

//Find Position case insenstive.
echo stripos($content, "OPERATIONS") . "<br>";

//UPPER and lower case
echo strtoupper($content) . "<br>";
echo strtolower($content) . "<hr>";

//Word Wrap the String and display it.
$content = "             Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";

echo wordwrap($content, 50) . "<hr>";
echo trim($content) . "<hr>";;
echo rtrim($content) . "<br>";;

?>